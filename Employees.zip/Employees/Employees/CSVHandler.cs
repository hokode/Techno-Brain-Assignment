﻿using CsvHelper;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace Employees
{
   public  class CSVHandler
    {

        public static List<Employee> GetEmployeesData(string csvfilepath)
        {
            
            List<Employee> employeesdata = new List<Employee>();
            using (var reader = new StreamReader(csvfilepath))
            using (CsvReader csvr = new CsvReader(reader))
            {
                csvr.Configuration.HasHeaderRecord = false;
                var records = csvr.GetRecords<Employee>().ToList();
                employeesdata = records;
            }

            return employeesdata;
        }


 
    }
}
