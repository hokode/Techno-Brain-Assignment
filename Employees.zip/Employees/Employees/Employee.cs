﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Employees
{
    public class Employee
    {

        public string Id { get; set; }

        public string ManagerId { get; set; }

        public decimal Salary { get; set; }

        public Employee(string id, string managerId, decimal salary)
        {
            //if Id is empty then throw a null exception
            if (string.IsNullOrWhiteSpace(id)) throw new ArgumentNullException(nameof(id));

            //if salary has no value the throw a null exception
            if (salary.Equals(null)) throw new  ArgumentNullException(nameof(salary));

            //if salary is less than zero then throw an out of range  Exception
            if (salary < 0) throw new ArgumentOutOfRangeException(nameof(salary));

            Id = id;
            ManagerId = managerId;
            Salary = salary;
        }

        public override string ToString()
        {
            return "ID: " + Id + "   ManagerId: " + ManagerId + "    Salary:" + Salary;
        }


    }
}
