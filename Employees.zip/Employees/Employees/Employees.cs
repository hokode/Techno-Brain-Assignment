﻿using System;
using System.Collections.Generic;

namespace Employees
{
   public class Employees
    {
        


        //This functions displays validated employee data froma csv file
        public static List<Employee> DisplayEmployeeRecords(string csvfilepathname)
        {
            //if csvfilepathname is empty throw a null exception
            if (string.IsNullOrWhiteSpace(csvfilepathname)) throw new ArgumentNullException(nameof(csvfilepathname));

            //get the data from the csv and assign to var records
            var employeesdata = CSVHandler.GetEmployeesData(csvfilepathname);

           

            //check if records has values to proceed else return null
            if (employeesdata != null)
            {

                Functions func = new Functions(employeesdata);
                if (func.ValidateEmployeesData())
                {
                    return employeesdata;
                }
            }

                return null;
        }

        //this function displays provided manager's salary budget
        public static long DisplayManagersBudget(string ManagerId, string csvfilepathname)
        {
            //if csvfilepathname is empty throw a null exception
            if (string.IsNullOrWhiteSpace(csvfilepathname)) throw new ArgumentNullException(nameof(csvfilepathname));

            //if ManagerId is empty throw a null exception
            if (string.IsNullOrWhiteSpace(ManagerId)) throw new ArgumentNullException(nameof(ManagerId));


            //get the data from the csv and assign to var records
            var employeesdata = CSVHandler.GetEmployeesData(csvfilepathname);

            //check if records has values to proceed else return null
            if (employeesdata != null)
            {
                Functions func = new Functions(employeesdata);
                return func.GetManagersSalaryBudget(ManagerId);
            }

                return 0;
        }

    }
}
