﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Employees
{
    public class Functions
    {
        private List<Employee> _employees;

        public Functions(List<Employee> employees)
        {
            _employees = employees ?? throw new ArgumentNullException(nameof(employees));
        }

        public bool ValidateEmployeesData()
        {
            //check if there is more than one CEO on the list and throw Exception.
            if (_employees.Where(e => e.ManagerId == string.Empty || e.ManagerId == null).Count() > 1) throw new Exception("There is more than one CEO Listed.");

            //Check if all Managers have been listed as employees. if not throw exception
            var managers = _employees.Where(r => r.ManagerId != null && r.ManagerId != string.Empty).Select(e => e.ManagerId);
            foreach (var manager in managers)
            {
                if (_employees.FirstOrDefault(e => e.Id == manager) == null) throw new Exception("Missing managers in the employee column.");
            }

            //Check if Employee has more than one manager listed. If true then throw exception.
            foreach (var id in _employees.Select(e => e.Id).Distinct())
            {
                if (_employees.Where(i => i.Id == id).Select(m => m.ManagerId).Distinct().Count() > 1)
                    throw new Exception($"Employee {id} has more than one manager listed.");
            }

            //check for circular reference i.e  first employee reporting to a second employee that is also under the first employee. 
            foreach (var employee in _employees.Where(e => e.ManagerId != string.Empty && e.ManagerId != null))
            {
                var id = _employees.Where(e => e.ManagerId != string.Empty && e.ManagerId != null)
                    .FirstOrDefault(e => e.Id == employee.ManagerId);
                if (id != null)
                    if (id.ManagerId == employee.Id)
                        throw new Exception("Circular reference  detected");
            }


            return true;
        }


        private bool isManager(string id) => _employees.Where(e => e.ManagerId == id).Count() > 0;


        public long GetManagersSalaryBudget(string managerId)
        {
            decimal total = 0;

            if( _employees.Count > 0)
            {
                total += _employees.FirstOrDefault(e => e.Id == managerId).Salary;

                foreach (var item in _employees.Where(e => e.ManagerId == managerId))
                {
                    if (isManager(item.Id))
                    {
                        total += GetManagersSalaryBudget(item.Id);
                    }
                    else
                    {
                        total += item.Salary;
                    }
                }

            }

            return Convert.ToInt64(total);

        }
    }
}
