﻿using System;
using System.Collections.Generic;

namespace Employees
{
    class Program
    {
        static void Main(string[] args)
        {
            //for debugging purpose
            string csvFilePath =  @"C:\Users\Jarvis\source\repos\DLL Project\Employees\EmployeesData.csv";
            string ManagerId = "Employee1";
            string title = "Manager  " + ManagerId + " Budget";

            var records = Employees.DisplayEmployeeRecords(csvFilePath);


            Console.WriteLine("Disruptive Solutions Employee Data");
            Console.WriteLine("*****************************************************************************************");

            foreach (Employee empdata in records)
            {
                Console.WriteLine(empdata);
            }

            Console.WriteLine("*****************************************************************************************");
            //let  us display the manager budget and see how that works 


            Console.WriteLine(title);
            Console.WriteLine("*****************************************************************************************");
            Console.WriteLine(Employees.DisplayManagersBudget(ManagerId, csvFilePath));


            Console.ReadKey();


           
        }

    }
}
