
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;

namespace EmployeesTests
{
    [TestClass]
    public class EmployeesTests
    {

        [TestMethod]
        public void DisplayEmployeeRecords_WhenDataFileisNotSpecified_ShouldReturnNullException()
        {
            //Arrange
            string csvfilepath = "";

            //Act & Assert
            Assert.ThrowsException<ArgumentNullException>(() => Employees.Employees.DisplayEmployeeRecords(csvfilepath));
        }

        [TestMethod]
        public void DisplayEmployeeRecords_WhenDataFileisEmpty_ShouldReturnNull()
        {
            //Arrange 
            double count = 0;
            double totalrecords = 0;
            string csvfilepath = @"C:\Users\Jarvis\source\repos\DLL Project\Employees\EmployeesNoData.csv";

            //Act
            var result = Employees.Employees.DisplayEmployeeRecords(csvfilepath);
            totalrecords = result.Count;
            //Act & Assert
            Assert.AreEqual(count, totalrecords, "File is empty.");

        }



        [TestMethod]
        public void DisplayManagersBudget_WhenDataFileisNotSpecified_ShouldReturnNullException()
        {
            //Arrange
            string csvfilepath = "";
            string ManagerId = "Employee2";

            //Act & Assert
            Assert.ThrowsException<ArgumentNullException>(() => Employees.Employees.DisplayManagersBudget(ManagerId, csvfilepath));
        }

        [TestMethod]
        public void DisplayManagersBudget_WhenManagerIdisNotSpecified_ShouldReturnNullException()
        {
            //Arrange
            string csvfilepath = @"C:\Users\Jarvis\source\repos\DLL Project\Employees\EmployeesData.csv";
            string ManagerId = "";

            //Act & Assert
            Assert.ThrowsException<ArgumentNullException>(() => Employees.Employees.DisplayManagersBudget(ManagerId, csvfilepath));
        }

        [TestMethod]

        public void ValidateEmployeesData_MoreThanOneCEOListed_ShouldThrowAnException()
        {
            //Arrange
            List<Employees.Employee> employees = new List<Employees.Employee>
            {
                new Employees.Employee("Employee1","",1800),
                new Employees.Employee("Employee2","",1000),
            };

            //Act
            Employees.Functions func = new Employees.Functions(employees);

            //Assert
            Assert.ThrowsException<Exception>(() => func.ValidateEmployeesData());     
        }


        [TestMethod]
        public void ValidateEmployeesData_EmployeeHasMoreThanOneManager_ShouldThrowAnException()
        {
            //Arrange
            List<Employees.Employee> employees = new List<Employees.Employee>
            {
                new Employees.Employee("Employee1","",1800),
                new Employees.Employee("Employee2","Employee1",1800),
                new Employees.Employee("Employee3","Employee2",800),
                new Employees.Employee("Employee3","Employee1",800),
            };

            //Act
            Employees.Functions func = new Employees.Functions(employees);

            //Assert
            Assert.ThrowsException<Exception>(() => func.ValidateEmployeesData());
        }

        [TestMethod]
        public void ValidateEmployeesData_CyclicReporting_ShouldThrowAnException()
        {
            //Arrange
            List<Employees.Employee> employees = new List<Employees.Employee>
            {
                new Employees.Employee("Employee1","",1800),
                new Employees.Employee("Employee2","Employee3",1800),
                new Employees.Employee("Employee3","Employee2",800),
                new Employees.Employee("Employee4","Employee1",800),
            };

            //Act
            Employees.Functions func = new Employees.Functions(employees);

            //Assert
            Assert.ThrowsException<Exception>(() => func.ValidateEmployeesData());
        }

        [TestMethod]
        public void ValidateEmployeesData_ManagersNotListedAsEmployees_ShouldThrowAnException()
        {
            //Arrange
            List<Employees.Employee> employees = new List<Employees.Employee>
            {
                new Employees.Employee("Employee1","",1800),
                new Employees.Employee("Employee2","Employee5",1800),
                new Employees.Employee("Employee3","Employee2",800),
                new Employees.Employee("Employee4","Employee1",800),
            };

            //Act
            Employees.Functions func = new Employees.Functions(employees);
            //Assert
            Assert.ThrowsException<Exception>(() => func.ValidateEmployeesData());
        }

        [TestMethod]
        public void Employee_IdNotInString_ShouldReturnException()
        {
            //Arrange 
            string Id = "";
            string ManagerId = "Employee1";
            decimal salary = 800;

            //Act
            //Assert
            Assert.ThrowsException<ArgumentNullException>(() =>  new Employees.Employee(Id, ManagerId, salary));
        }

        [TestMethod]
        public void Employee_SalaryIsEqualToZero_ShouldReturnException()
        {
            //Arrange 
            string Id = "Employee";
            string ManagerId = "Employee1";
            decimal salary = 0;

            //Act
            Employees.Employee emp = new Employees.Employee(Id, ManagerId, salary);

            //Assert
            Assert.AreEqual(0, salary, "Salary is 0.");
        }


    }

   
}
